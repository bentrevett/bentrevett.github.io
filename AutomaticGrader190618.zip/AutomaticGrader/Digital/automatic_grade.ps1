#$limit = 60 #how long we'll wait for before forcing the results file to be deleted

#the results file basically acts as a lock
#you create a blank results file when you start getting your results
#you delete it once you're done
#if a results file already exists when you try and get results, you know someone is getting
#results already and wait for them to finish and delete the file, then you create your own results file
#however, if somthing goes wrong when someone is getting their results, the file might be left undeleted
#hence, we check how long ago the results file was last modified, if it was over %limit seconds ago
#we forcibly delete the results file and make our own

#while (Test-Path results.txt){ #someone might be getting results, so we wait until they delete the results file
#	$results_last_mod = (Get-Item "results.txt").LastWriteTime;
#	$curr_time = Get-Date
#	$time_since_last_mod = (New-TimeSpan -Start $results_last_mod -End $curr_time).TotalSeconds
#	if ($time_since_last_mod -gt $limit){
#		Remove-Item results.txt
#		break
#	}
#	Start-Sleep -s 5	
#}
#New-Item results.txt -ItemType file >$null #create blank results file and send the output to null so it doesn't display

UV4 -d BasicUI.uvproj #open project in debug mode
Start-Sleep -s 4 #wait 3 seconds
$wshell = New-Object -ComObject wscript.shell
$wshell.SendKeys('~') #tilde means pressing enter
Start-Sleep -s 1
if( $wshell.AppActivate('Automatic Grader') ) #sometimes the autograder automatically opens
{
	Start-Sleep -s 1
}
else { #if not, we have to manually open it
	$wshell.SendKeys('%R')
	Start-Sleep -s 1
	$wshell.SendKeys('{UP}')
	Start-Sleep -s 1
	$wshell.SendKeys('~')
	Start-Sleep -s 1
}
$wshell.SendKeys('~')
Start-Sleep -s 5
$wshell.SendKeys('%F')
Start-Sleep -s 1
$wshell.SendKeys('{UP}')
Start-Sleep -s 1
$wshell.SendKeys('~')
Start-Sleep -s 3
Get-Content results.txt #print results from file
#Remove-Item results.txt