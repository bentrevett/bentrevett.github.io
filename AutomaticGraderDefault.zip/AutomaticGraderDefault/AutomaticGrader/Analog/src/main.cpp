/*----------------------------------------------------------------------------
LAB EXERCISE 9 - Analog input and PWM
 ----------------------------------------
	Use two potentiometers to adjust the volume and pitch of the output sound wave.
	
	Inputs: potentiometers 1 and 2
	Output: speaker, PC

	GOOD LUCK!
 *----------------------------------------------------------------------------*/

#include "mbed.h"
//#include "MKL25Z4.H"

//Define the PWM speaker output
PwmOut speaker(D6);
//DigitalOut led(PTA0);

//Define analog inputs
AnalogIn pot1(A0);
AnalogIn pot2(A1);
/*AnalogIn pot3(A2);
AnalogIn pot4(A3);
AnalogIn pot5(A4);
AnalogIn pot6(A5);*/


//Define serial output
//Serial pc(USBTX, USBRX);

//Define variables
float val1;
float val2, val3, val4, val5, val6;
float i; int done;
/*----------------------------------------------------------------------------
 MAIN function
 *----------------------------------------------------------------------------*/
int main(){
	done = 0;
	while(1){
		val1 = pot1.read();
		val2 = pot2.read();
		
		/*
		volatile int j;
		for(j=0; j<1000000; j++) {
			j++;
		}
		*/

		//Print values to the PC
		//pc.printf("Pot1: %f     Pot2: %f\r", val1, val2);
		
		//Create a saw-tooth sound wave

		for(i=0; i<1; i+=0.05){
			speaker.period(0.003125-(0.003*val1));
			speaker = i*0.05*val2;
			
		}
		done++;

	}
}

// *******************************ARM University Program Copyright � ARM Ltd 2014*************************************
